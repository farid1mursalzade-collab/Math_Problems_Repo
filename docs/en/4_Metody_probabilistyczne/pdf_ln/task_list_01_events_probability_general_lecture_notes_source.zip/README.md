Source package for the corrected lecture notes.

Files:
- main.tex: LaTeX source

Compile with:
    pdflatex main.tex
    pdflatex main.tex

No external graphics or font files are required.
