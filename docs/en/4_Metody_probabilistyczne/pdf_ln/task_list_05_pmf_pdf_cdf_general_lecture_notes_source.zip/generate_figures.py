import math
import numpy as np
import matplotlib.pyplot as plt

out = '/mnt/data/pmf_pdf_cdf_general_notes/figures'
plt.rcParams.update({
    'figure.figsize': (6.8, 4.2),
    'font.size': 10,
    'axes.spines.top': False,
    'axes.spines.right': False,
    'axes.grid': True,
    'grid.alpha': 0.25,
})

# 1. Discrete PMF and CDF from a custom distribution
x = np.array([-1, 0, 2, 4, 7])
p = np.array([0.12, 0.18, 0.30, 0.25, 0.15])
F = np.cumsum(p)
fig, ax = plt.subplots()
ax.vlines(x, 0, p, lw=3)
ax.scatter(x, p, s=45, zorder=3)
ax.set_xlabel('x')
ax.set_ylabel('p_X(x)')
ax.set_title('A probability mass function')
ax.set_ylim(0, max(p)*1.25)
fig.tight_layout()
fig.savefig(f'{out}/discrete_pmf.pdf')
plt.close(fig)

fig, ax = plt.subplots()
# step right-continuous
xs = np.r_[x[0]-1, x, x[-1]+1]
ys = np.r_[0, F, F[-1]]
ax.step(xs, ys, where='post', lw=2.5)
ax.scatter(x, F, s=35, zorder=3)
ax.set_xlabel('x')
ax.set_ylabel('F_X(x)')
ax.set_title('The corresponding cumulative distribution function')
ax.set_ylim(-0.05, 1.05)
fig.tight_layout()
fig.savefig(f'{out}/discrete_cdf.pdf')
plt.close(fig)

# Helper functions
def comb(n, k):
    if k < 0 or k > n:
        return 0
    return math.comb(n, k)

def binom_pmf(k, n, prob):
    return comb(n, k) * prob**k * (1-prob)**(n-k)

# 2. Binomial PMF comparisons
fig, ax = plt.subplots()
ks = np.arange(0, 21)
for prob, label in [(0.25, 'p=0.25'), (0.50, 'p=0.50'), (0.75, 'p=0.75')]:
    vals = np.array([binom_pmf(k, 20, prob) for k in ks])
    ax.plot(ks, vals, marker='o', lw=1.8, label=label)
ax.set_xlabel('number of successes')
ax.set_ylabel('probability')
ax.set_title('Binomial distributions with fixed n=20')
ax.legend(frameon=False)
fig.tight_layout()
fig.savefig(f'{out}/binomial_comparison.pdf')
plt.close(fig)

# 3. Geometric PMF and CDF
fig, ax = plt.subplots()
k = np.arange(1, 26)
for prob, label in [(0.15, 'p=0.15'), (0.35, 'p=0.35')]:
    vals = (1-prob)**(k-1)*prob
    ax.plot(k, vals, marker='o', lw=1.8, label=label)
ax.set_xlabel('trial of first success')
ax.set_ylabel('probability')
ax.set_title('Geometric distributions')
ax.legend(frameon=False)
fig.tight_layout()
fig.savefig(f'{out}/geometric_comparison.pdf')
plt.close(fig)

# 4. Poisson PMF comparisons
fig, ax = plt.subplots()
k = np.arange(0, 21)
for lam, label in [(2, '$\\lambda=2$'), (6, '$\\lambda=6$'), (10, '$\\lambda=10$')]:
    vals = np.array([math.exp(-lam)*lam**kk/math.factorial(kk) for kk in k])
    ax.plot(k, vals, marker='o', lw=1.8, label=label)
ax.set_xlabel('number of events')
ax.set_ylabel('probability')
ax.set_title('Poisson distributions')
ax.legend(frameon=False)
fig.tight_layout()
fig.savefig(f'{out}/poisson_comparison.pdf')
plt.close(fig)

# Beta pdf
from math import gamma

def beta_pdf(x, a, b):
    B = gamma(a)*gamma(b)/gamma(a+b)
    return x**(a-1)*(1-x)**(b-1)/B
fig, ax = plt.subplots()
t = np.linspace(0.001, 0.999, 500)
for a,b,label in [(0.7,0.7,'a=b=0.7'), (2,5,'a=2,b=5'), (5,2,'a=5,b=2'), (6,6,'a=b=6')]:
    ax.plot(t, beta_pdf(t,a,b), lw=2, label=label)
ax.set_xlabel('x')
ax.set_ylabel('density')
ax.set_title('Beta density shapes')
ax.legend(frameon=False)
fig.tight_layout()
fig.savefig(f'{out}/beta_comparison.pdf')
plt.close(fig)

# Gamma pdf
def gamma_pdf(x, alpha, theta):
    return x**(alpha-1)*np.exp(-x/theta)/(gamma(alpha)*theta**alpha)
fig, ax = plt.subplots()
t = np.linspace(0.001, 20, 600)
for alpha,theta,label in [(1,2,'alpha=1, theta=2'), (2,2,'alpha=2, theta=2'), (5,1,'alpha=5, theta=1')]:
    ax.plot(t, gamma_pdf(t, alpha, theta), lw=2, label=label)
ax.set_xlabel('x')
ax.set_ylabel('density')
ax.set_title('Gamma density shapes')
ax.legend(frameon=False)
fig.tight_layout()
fig.savefig(f'{out}/gamma_comparison.pdf')
plt.close(fig)

# Normal pdf and cdf
fig, ax = plt.subplots()
t = np.linspace(-6, 6, 700)
for mu, sig, label in [(0,1,'mu=0, sigma=1'), (2,1,'mu=2, sigma=1'), (0,2,'mu=0, sigma=2')]:
    vals = np.exp(-0.5*((t-mu)/sig)**2)/(sig*np.sqrt(2*np.pi))
    ax.plot(t, vals, lw=2, label=label)
ax.set_xlabel('x')
ax.set_ylabel('density')
ax.set_title('Normal density shapes')
ax.legend(frameon=False)
fig.tight_layout()
fig.savefig(f'{out}/normal_comparison.pdf')
plt.close(fig)

# CDF conceptual continuous
fig, ax = plt.subplots()
t = np.linspace(-4,4,500)
cdf = 0.5*(1+np.vectorize(math.erf)(t/np.sqrt(2)))
ax.plot(t, cdf, lw=2.5)
ax.set_xlabel('x')
ax.set_ylabel('F_X(x)')
ax.set_title('A smooth CDF for a continuous distribution')
ax.set_ylim(-0.05,1.05)
fig.tight_layout()
fig.savefig(f'{out}/continuous_cdf.pdf')
plt.close(fig)
