# Task List 02 - Combinatorics for Probability: General Lecture Notes

This archive contains the LaTeX source for the PDF lecture notes.

Main source file:

- `task_list_02_combinatorics_general_lecture_notes.tex`

Recommended compilation:

```bash
latexmk -xelatex task_list_02_combinatorics_general_lecture_notes.tex
```
