# Task List 03 - Probability Distributions: General Lecture Notes

This archive contains the LaTeX source for the PDF lecture notes.

Main source file:
- task_list_03_probability_distributions_general_lecture_notes.tex

No external graphics are required; figures are generated directly with TikZ inside the LaTeX source.

To compile:

```bash
latexmk -pdf task_list_03_probability_distributions_general_lecture_notes.tex
```
